def demo():
    print('null arguments')


def demo(a, b):
    print(a + b)


# In pyhton function overloading is not allowed
demo()

