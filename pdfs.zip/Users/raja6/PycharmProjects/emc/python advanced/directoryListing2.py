import os

dir_path = r'C:\Users\raja6\PycharmProjects\emc'
print(os.listdir(dir_path))
