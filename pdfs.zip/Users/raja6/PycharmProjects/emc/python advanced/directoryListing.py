class DirectoryListing:
    def __init__(self, *args):
        print(args)


if __name__ == '__main__':
    DirectoryListing('d1', 'd2')

